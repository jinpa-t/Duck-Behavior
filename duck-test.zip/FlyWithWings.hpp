class FlyWithWings : public FlyBehavior {
    public:
        void fly() {
            std::cout << ("I'm flying!!\n");
        }
};
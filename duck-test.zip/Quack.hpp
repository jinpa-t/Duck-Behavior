class Quack : public QuackBehavior {
    public:
        void quack() {
            std::cout << ("Quack\n");
        }
};

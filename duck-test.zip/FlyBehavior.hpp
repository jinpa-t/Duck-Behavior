class FlyBehavior {
    public:
        virtual void fly() = 0;
};
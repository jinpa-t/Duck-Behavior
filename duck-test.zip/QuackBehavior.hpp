class QuackBehavior {
    public:
        virtual void quack() = 0;
};

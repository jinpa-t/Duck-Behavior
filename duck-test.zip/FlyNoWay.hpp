class FlyNoWay : public FlyBehavior {
    public:
        void fly() {
            std::cout << ("I can't fly\n");
        }
};
class Squeak : public QuackBehavior {
    public:
    void quack() {
        std::cout << ("Squeak\n");
    }
};
